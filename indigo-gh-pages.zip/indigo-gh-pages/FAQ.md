# FAQ:

- Article: How to Install Jekyll - by [Arti Annaswamy](https://github.com/aannasw). [Part 1](https://artiannaswamy.com/build-a-github-blog-part-1) and [Part 2](https://artiannaswamy.com/build-a-github-blog-part-2)
- [How to build and run a Jekyll site in a Docker container](https://mehmandarov.com/disposable-docker-containers/)
- [Emojis in the projects list?](https://github.com/sergiokopplin/indigo/issues/72)
- [Nokogiri dependencie problems?](https://github.com/sergiokopplin/indigo/issues/81)
- [Syncing a Fork](https://help.github.com/articles/syncing-a-fork/)
- [Tests with Travis CI - Tutorial](https://www.raywenderlich.com/109418/travis-ci-tutorial)
- [Why Sass?](https://github.com/sergiokopplin/indigo/issues/117)
- [Jekyll Example](https://github.com/barryclark/jekyll-now) - how to clone, run and edit jekyll configs
